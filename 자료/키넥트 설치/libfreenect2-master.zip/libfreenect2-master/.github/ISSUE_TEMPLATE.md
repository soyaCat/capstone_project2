Overview Description:

<!-- Check https://github.com/OpenKinect/libfreenect2/wiki/Troubleshooting if you haven't done so. -->

Version, Platform, and Hardware Bug Found:

1. `git log -1 --oneline`
2. `uname -a`
3. `lsusb -t`
4. `lspci -nn`

Steps to Reproduce:

1. 
2. 
3. 

Actual Results:

Expected Results:

Reproducibility:

Additional Information:
